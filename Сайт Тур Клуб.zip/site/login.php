<!DOCTYPE html>
<html lang="RU"> 

<head> 
<!-- // Кодировка языка на сайте -->
	<meta charset="utf-8"> 
	<!-- // Помогает IE определить страницу как HTML документ -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<!-- // Название, которое отображается на табе страницы -->
	<title>Авторизация</title> 
	<!-- // Подключение стилей -->
	<link rel="stylesheet" href="css/style.css"> 
</head>
<!-- // Начало тела сайта -->
<body>  
<!-- // Подключение файла с меню сайта -->
	<?php
    //Подключение шапки
    require_once("header.php");
?>
	<!-- // контейнер для выравнивания формы  -->
	<div class="form-container"> 
	<!-- // Форма с указанием action и методом передачи данных -->
		<form class="form" action="form_login.php" method="POST" enctype="application/x-www-form-urlencoded"> 
		<!-- // Лейбел для поля с логином -->
			
			<!-- // Поле для ввода логина -->
			<input class="form__input" type="name" name="login" placeholder="Введите логин"> 
			<br>
			<!-- // Лейбел для поля с паролем -->
			
			<!-- // Ссылка на страницу восстановления пароля -->
			
			<!-- // Поле для ввода пароля -->
			<input class="form__input" type="password" name="password" placeholder="Введите пароль"> 
			<!-- // Нижняя часть с ссылкой и кнопкой -->
			<div class="form__lower"> 
			<!-- // Ссылка на форму регистрации -->
				<a class="form__link" href="register.php">Регистрация</a> 
				<!-- // Кнопка отправки формы -->
				<input class="form__btn" type="submit" value="Войти"> 
				<p class="form__reset-password"><a href="#">Забыли пароль?</a></p> 
			</div>
		</form>

	</div>
</body>
<footer class="f_obr">
   <hr>
 <?php
    //Подключение подвала
    require_once("footer.php");
?>
</footer>
</html>