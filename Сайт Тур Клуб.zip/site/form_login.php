<?php
session_start(); // Запускаем сессию

require 'db.php'; // Подключаем базу

if ($_POST['login'] !== '' && $_POST['password'] !== '') { // Проверяем наличие логина и пароля

  $query = "SELECT `login`, `password` FROM `users` WHERE `login` = ?"; // Строим запрос делая выборку логина и пароля
  $data = $db->prepare($query); // Подготавливаем запрос
  
  $_POST['login'] = trim($_POST['login']); // Убераем пробелы у логина
  $_POST['password'] = trim($_POST['password']); // Убераем пробелы у пароля

  $data->execute([$_POST['login']]); // Выполняем выборку

  $row = $data->fetch(PDO::FETCH_ASSOC); // Выбираем строчку и превращаем её в ассоциативный массив

  if ($_POST['login'] !== $row['login']) { // Свераяем логин пользоывтеля и логин в базе
    error('Пользователь не зарегестрирован');
  }

  if (!password_verify($_POST['password'], $row['password'])) { // Сверяем пароль пользователя с хэшем из базы
    error('Не верный пароль');
  }

  $_SESSION['user'] = $row['login'];
  header('Location: /index.php');

}

function error($error) { // Функция принимающая строку
  $_SESSION['error'] = $error; // Занесение ошибка в массив
  die(header('Location: ../login.php')); // Убийство скрипта и перенаправление
}
echo '<meta http-equiv="Refresh" content="0; URL=/login.php" />';