
<!DOCTYPE html>
<html>
    <head>
        <title>Туристический клуб "4.20"</title>
        <meta charset="utf-8">
        <link rel=”icon” href=”/favicon.ico” type=”image/x-icon>
        <link rel="stylesheet" type="text/css" href="css/styles.css">

        <div id="header">
            
 
            
            <a target="_blank" href="/index.php">
                    <img src="https://26kadr.mskobr.ru/attach_files/logo/Logo-02.png" alt="Государственное и муниципальное управление" align="left" width="50px" height="50px" >
                </a>
 
            <div id="auth_block">
                    <div id="link_register">


                        
                <a target="_blank" href="/register.php">
                    <img src="https://cdn-icons-png.flaticon.com/512/40/40358.png" alt="Регистрация" align="right" width="50px" height="50px" >
                </a>

                    </div>

             
                    <div id="link_auth">

                       
                                          
                <a target="_blank" href="/login.php">
                    <img src="https://cdn-icons-png.flaticon.com/512/1000/1000997.png" alt="Авторизация" align="right" width="50px" height="50px" hspace="20" >
                </a>
                    </div>
          
                    
                    <div align="center">
                        <a  href="/o_nas.php">О нас</a>
                    </div>
                    <div align="center">
                        <a href="/obratnay_s.php">Обратная связь</a>
                    </div>
                    <div align="center">
                        <a href="/napravlenia.php">Наши направления</a>
                    </div>
            </div>
             <div class="clear"></div>
        </div>
        <hr>