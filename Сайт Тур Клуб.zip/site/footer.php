        <link rel="stylesheet" type="text/css" href="/css/style.css">
        <div id="footer">
            
            <div id="h1">
            <h2 id="2" align="left">
                Наши социальные сети
            </h2>
            </div>
             <a target="_blank" href="https://vk.com/suetolog_a">
            <img id="png__footer" src="https://pngicon.ru/file/uploads/vk-256x256.png"  alt="Вк" align="left" width="40px" height="40px" hspace="10"></a>
             <a target="_blank" href="https://vk.com/suetolog_a">
            <img id="png__footer" src="https://st.mycdn.me/res/i/ok_logo.png"  alt="Одноклассники" align="left" width="40px" height="40px" hspace="10"></a>
             <a target="_blank" href="https://vk.com/suetolog_a">
            <img id="png__footer" src="https://pngimg.com/uploads/twitter/small/twitter_PNG95259.png"  alt="Фейсбук" align="left" width="40px" height="40px" hspace="10"></a>
             <a target="_blank" href="https://vk.com/suetolog_a">
            <img id="png__footer" src="https://pngicon.ru/file/uploads/FaceBook_512x512.png"  alt="Твиттер" align="left" width="40px" height="40px" hspace="10"></a>

            <div id="h2">
            <h2 id="1" align="right">
                Наше местоположение
            </h2>
        </div>
         <a target="_blank" href="https://www.google.com/maps/place/Варшавское+ш.,+16+корпус+2,+Москва,+117105/@55.6924298,37.6160486,17z/data=!3m1!4b1!4m5!3m4!1s0x46b54b565a54a521:0xd58e4d826e07dc73!8m2!3d55.6924298!4">
            <img id="png" src="https://cdn-icons-png.flaticon.com/512/854/854878.png"  alt="Карта" align="right" width="100px" height="100px" hspace="10"></a>

        </div>
            <h5 align="center">2021 © Департамент образования и науки города Москвы 2021 © Разработка и поддержка ГАУ «Центр цифровизации образования» Полное или частичное копирование материалов защищенных</h5>
            <h5 align="center">  баннерами уникальности и принадлежавшие авторам нашего сайта. Разрешено только при обязательном указании автора и прямой гиперссылки на сайт "Я ХОЗЯИН",и с письменного разрешения администрации сайта!</h5>
        
    </body>
</html>