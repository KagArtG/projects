<?php 
session_start();

require 'db.php';


if(trim($_POST['login'] !== '') && trim($_POST['password'] !== '')) { // Проверка есть ли логин и пароль, удаление пробелов

    $query = "INSERT INTO `users` (`login`, `password`) VALUES (:login, :password)"; // SQL запрос к базе users, а именно к столбцам login и password

    $params = [ // формирование параметров для передачи в базу в видео объекта
      ':login' => trim($_POST['login']), // логин без пробелов
      ':password' => password_hash(trim($_POST['password']), PASSWORD_DEFAULT) // пароль без пробелов
    ];

    $data = $db->prepare($query); // Подготавливаем запрос

    $data->execute($params); // Отправляем параметры

    $_SESSION['user'] = $_POST['login']; // Заносим пользователя в базу
     header('Location: /login.php'); // перенаправляем на главную

} 
// Описываем ошибку что пользователь не ввёл все данные