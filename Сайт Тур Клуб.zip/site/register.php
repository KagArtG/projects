<!DOCTYPE html>
<html lang="RU">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Регистрация</title>
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
	<?php
    //Подключение шапки
    require_once("header.php");
?>
	<div class="form-container">
		
		<form class="form" action="form_register.php" method="POST" enctype="application/x-www-form-urlencoded">
			
			<input class="form__input" type="name" name="login" placeholder="Введите логин">
			<br>
			
			
			<input class="form__input" type="password" name="password" placeholder="Введите пароль">
			<div class="form__lower">
				<a class="form__link" href="login.php">Войти</a>
				<input class="form__btn" type="submit" value="Зарегистрироваться">
			</div>
		</form>

	</div>
</body>
<footer class="f_obr">
   <hr>
 <?php
    //Подключение подвала
    require_once("footer.php");
?>
</footer>

</html>