<?php
    //Подключение шапки
    require_once("header.php");
?>
<div class="nomer">
<input id="nomer" align="center"   placeholder="Введите номер телефона">
</div>
<div class="name">
<input id="name" align="center"   placeholder="Введите имя">
</div>
<div class="familia">
<input id="familia" align="center"   placeholder="Введите фамилию">
</div>
<div class="otziv">
<input id="otziv" align="center"   placeholder="Введите отзыв">
</div>
<div>
<input class="form__btn" type="submit" placeholder="Отправить отзыв" >
<a  class="form__link" href="index.php">Отправить отзыв</a>
</div>
<footer class="f_obr">
   <hr>
 <?php
    //Подключение подвала
    require_once("footer.php");
?>
</footer>