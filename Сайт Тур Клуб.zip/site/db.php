<?php

// Подключение с проверкой на ошибки подключения
try {
  // Поделючение к базе
  $db = new PDO('mysql:host=localhost;dbname=register', 'root', '');
} catch (PDOException $e) { // Вылавливаем ошибки, если они есть
  print "Error!: " . $e->getMessage(); // Выводим текст ошибки
  die(); // Завершаем работу всего скрипта
}