<div id="auth_block">
<?php
    //Проверяем авторизован ли пользователь
    if(!isset($_SESSION['email']) && !isset($_SESSION['password'])){
        // если нет, то выводим блок с ссылками на страницу регистрации и авторизации
?>
        <div id="link_register">
            <a href="/form_register.php">Регистрация</a>
        </div>
 
        <div id="link_auth">
            <a href="/form_auth.php">Авторизация</a>
        </div>
<?php
    }else{
        //Если пользователь авторизован, то выводим ссылку Выход
?> 
        <div id="link_logout">
            <a href="/logout.php">Выход</a>
        </div>
<?php
    }
?>
</div>
<?php
    //Запускаем сессию
    session_start();
 
    unset($_SESSION["email"]);
    unset($_SESSION["password"]);
     
    // Возвращаем пользователя на ту страницу, на которой он нажал на кнопку выход.
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: ".$_SERVER["HTTP_REFERER"]);
?>