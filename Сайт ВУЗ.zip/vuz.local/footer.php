        <div id="footer">
            <h2>Подвал сайта</h2>
        </div>
    </body>
</html>